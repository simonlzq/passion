#!/usr/bin/env bash

docker kill gridstudio