# docker build --no-cache . -t gridstudio
docker build . -t gridstudio