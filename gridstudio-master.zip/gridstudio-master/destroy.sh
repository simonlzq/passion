#!/usr/bin/env bash

docker rm -f gridstudio