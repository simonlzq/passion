## Guide for contributors

In this document a list of all contributors is kept in order to appreciate and acknowledge everyone who has contributed to this open source project.



